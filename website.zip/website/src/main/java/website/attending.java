package website;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/website/wedding.jsp")
public class attending extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		// 세션 지우는거 - 로그아웃 개념
		session.invalidate();
		response.sendRedirect("/website/wedding.jsp");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String name = request.getParameter("name");
		String email = request.getParameter("email");

		if(name != null && email != null) {
			request.getRequestDispatcher("/website/wedding.jsp").forward(request, response);
			HttpSession session = request.getSession();
			session.setAttribute("name", name);
			//response.sendRedirect("/attending.do");
		}else {
			request.setAttribute("message","다시 입력해주세요");
		}
		 
	}

}
